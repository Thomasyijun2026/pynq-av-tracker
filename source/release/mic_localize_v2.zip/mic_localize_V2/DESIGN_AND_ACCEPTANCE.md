# MIC01/05/07/08 stability V2

## Objective and protected baseline

User request 2026-10-28: explain the two accepted V1 bearing jumps, improve stability with computation mainly in PL, then give concrete instructions for a controlled sound test. Original V1 sources, sealed `release/mic_localize_V1.zip`, old overlay, raw captures, all accepted/rejected records remain unchanged. No new hardware request, background monitor, or agent window is authorized by this offline phase.

## Diagnosis established before changing the algorithm

`logs/mic_stability_V2/diagnosis_V2.json` recomputes six neighboring windows from the two hash-checked original recordings. The 202 full-window sums agree with V1. The six peaks in both jumps are positive correlation peaks, so a change of correlation polarity does not explain them. Removing the four highest-energy 512-frame blocks leaves round006 at -121.924 degrees; a single short impulse is not a sufficient explanation. Applying a stronger high-pass FIR also fails to resolve round006 and reduces acceptance in ordinary neighboring windows. These alternatives are diagnostic comparisons, not deployed filters.

`temporal_exploration_V2.json` separates each 32768-frame window into four 8192-frame windows. In round006/window2 the first two give -120.983/-122.283 degrees; the last two fail the existing geometry/cycle gates. In round013/window3 the first two give 15.783/16.085 degrees, the last two -120.585/-123.772 degrees. An energy-weighted full-window sum blends different delay states and can pass all V1 single-window gates. V1 has no check for agreement within the window. This establishes the algorithmic path to the jumps; the physical source of the additional coherent component remains unmeasured.

## Candidate fixed before full regression

Keep the V1 FIR, 32768-sample window, 33-lag range, six pairs, 202 signed64 values, interpolation, geometric fit, and every existing acceptance threshold. Add four nonoverlapping subwindows of 8192 samples. PL accumulates each subwindow correlation and finds its six integer absolute-peak lags. For a subwindow to support the full result, all six integer lags must be within one sample of the corresponding full-window lag. At least three of four subwindows must support it. One sample covers the relative rounding difference of two integer peak estimates; three-of-four requires a majority that tolerates one disturbed block. Neither rule uses the expected bearing or previous angle.

PL performs subwindow sums, peak searches, six-pair comparisons, support-mask/count and the temporal-stability flag. PS retains the existing interpolation/geometric checks and combines their result with the PL flag. Invalid output has no current bearing; its unfiltered candidate and rejection reasons are retained. No angle averaging, stale-angle substitution, or photograph-based gate is permitted.

## Acceptance gates declared before full replay

1. Reproduce all 976 V1 windows from all 122 raw files: every raw hash and 202-value baseline must match the saved evidence; preserve all 35 original rejections.
2. Both diagnosed mixed-delay windows must be rejected by the additional guard. Record every newly rejected window. Retain at least 95% of the other 939 previously accepted windows; this is coverage of this dataset, not measured angular accuracy.
3. Existing 22 synthetic direction/noise cases retain <2-degree bearing error and <0.12-sample lag error. Silence, uncorrelated noise, identical channels, dead channels and near-pure tones remain rejected. Modulated level changes with a fixed direction must not be confused with an angle change.
4. Known synthesized step changes across several arbitrary angles: reject a window split 2/2 between delay states; accept the next fully stable window without needing an expected angle or previous-state reset. Record limitations for unresolved close angles and simultaneous sources.
5. RTL must match the integer reference for all full sums, all 24 subwindow peaks, support masks and flags, including full int24 range, reset/re-arm/abort, overload and exact tolerance boundaries. Also verify the AXI/I2S path and read-only new register behavior.
6. Build using fixed Vivado 2026.1 for xc7z020clg400-1; inspect timing, resources, DRC and CDC before packaging a candidate. Hardware acceptance and physical direction accuracy are separate pending gates.

## Current execution and recovery

See `PROJECT_STATE.md` for the current step. Commands are recorded in `logs/mic_stability_V2/commands.jsonl`; Python is the fixed Vivado 2026.1 Python with -B and D: temporary directories. Automation pynq remains PAUSED. Last reliable board state remains V1 round021. Do not reuse a previous Jupyter execution request or assume the board is idle from these offline results.
