# MIC01/05/07/08 PL localization V2

Status: **OFFBOARD_CANDIDATE**. V2 reference regression, RTL simulation, routed implementation and portable replay pass. V2 has not been loaded onto the physical board in this task. Physical direction accuracy remains NOT_VALIDATED. The original V1 package is preserved.

## What changed

The PL still calculates the same FIR, six full-window correlations, four energies and six integer peaks. V2 adds four subwindow correlations, 24 integer peaks and an all-six-pairs consistency test in PL. At least three of four subwindows must agree with the full-window peaks within one sample. PS combines this flag with the unchanged V1 quality/geometry checks. Invalid current direction is null; the diagnostic candidate is retained.

Target: PYNQ-Z2, xc7z020clg400-1, Vivado 2026.1, FCLK100 MHz, Fs31250 Hz. Original 40-pin wiring remains; use source/fpga/audio_localize_V2/WIRING.md. DOA ABI is 0x444f4102, incompatible with the V1 snapshot reader.

Each capture freezes one 32768-frame PL snapshot after skipping 31250 raw frames. Later windows in a 10-second recording are analyzed offline. Repeated register reads do not produce new snapshots. A continuously refreshed localization output is not implemented in this release.

## Files and offline verification

- mic_localize.bit / mic_localize.hwh: matching final 2026.1 output.
- run_localizer_V2.py: explicit, bounded capture CLI; import and verify do not access hardware.
- runtime_manifest_localize_V2.json: all nine required runtime files with SHA256, target identity and allowed existing overlays.
- replay_bundle_V2.py / examples/: two historical jump windows and one stable neighbor, with exact V2 expected features, peaks and masks. Inputs are V1 physical recordings; expectations are V2 reference/RTL results. They are not V2 board observations.
- verify_capture.py: host verifier for a future V2 capture, including raw metadata, full/subwindow peaks, guard, channel statistics and independent diagnostic bands.
- source/: complete RTL, simulation vectors, Tcl/XDC, Python and source-generation/test scripts.
- evidence/: simulation, source integrity, timing, DRC/CDC and replay records. TEST_REPORT.md explains results and limits.
- sound/broadband_20s_V1.wav and SOUND_TEST.md: source and procedure for the next controlled experiment.

With Python3 and NumPy installed, from this directory:

```text
python3 -B run_localizer_V2.py verify
python3 -B replay_bundle_V2.py --out replay_check_V1.json
```

Use a new output path each time. Portable replay does not import PYNQ or connect to a board. The two jumps should be rejected with support=2; stable013 should be accepted. Floating-point estimates allow 1e-9 absolute / 1e-12 relative tolerance; all 202 integer sums, 30 integer peaks and guard fields must agree exactly.

## Board admission

Coordinate source placement and playback first, then inspect existing kernels, DMA and active overlay. Run in a fresh process/kernel with this bundle's modules, keeping V1 intact. The tested SD identity is in the runtime manifest. Do not reuse an old execution request or overwrite an existing result directory.

The following is an explicit board action, only after preflight and a ready sound source:

```text
python3 -B run_localizer_V2.py capture --seconds 10 --out test_front_V1
```

The entry point requires an idle known overlay/DMA, verifies runtime hashes, and invokes the unchanged V1 bounded capture/cleanup engine. It writes raw PCM, metadata, the V2 PL snapshot and localization.json. CAPTURE_VERIFIED means digital capture/cleanup checks passed; VALID_BEARING means the stated algorithm gates passed. Neither establishes angular accuracy. Keep invalid candidate directions and reasons.

Compare the first PL snapshot against the raw data with verify_capture.py after collection. Close any task-created Jupyter kernel only after clock/DMA/buffer cleanup has been confirmed. When communication fails, retain the existing request/result and inspect it before taking another action.

## Rebuilding and evidence

Project runners are pinned to D:\pynq_av_localizer and the user's installed 2026.1 tools. In that project use a fresh ASCII RunName with fpga/audio_localize_V2/scripts/run_tool.ps1; PowerShell policy is unchanged, so the project uses the documented ScriptBlock loader. The relative Tcl sources can also be used from another deliberate build root. Do not invoke the pinned wrapper from an extracted folder expecting it to build that folder automatically.

Full 976-window regression requires the retained original logs/mic_monitor_V1 recordings in the project. This portable package includes three compact excerpts and the full-regression summary plus SHA of the larger local evidence. No private transport credentials or large regenerated build caches are packaged.
