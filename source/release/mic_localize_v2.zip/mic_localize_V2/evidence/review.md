# V2 build admission review

Vivado 2026.1 build_V1 exited 0 at PC 2026-10-28 12:17:09. The final saved timing report and timing_metrics.tsv give setup 0.325 ns and hold 0.035 ns at 100 MHz; the earlier routing estimate was 0.288/0.033 ns. Use the final saved report. Resource use is 11295 LUT, 9644 registers, 2 DSP and 1.5 BRAM, versus V1 10264/9423/2/1.5. The temporal test adds 1031 LUT and 221 registers, with no additional DSP or BRAM tiles.

verify_build.py checks all 57 frozen source files, both actual simulation pass markers, completed command records, target pins/standards, internal and external timing, CDC, PS/DMA/custom-IP HWH parameters and addresses, XSA CRC and embedded bit/HWH byte equality. Admission result is OFFBOARD_PASS, not a board-test result.

Warnings remain visible and are not suppressed:

- DPOP-1(1) and DPOP-2(2): the reused 22x22 multiplier does not use every internal DSP pipeline register. Actual routed timing passes at the unchanged 100 MHz target. Further pipelining would require another functional regression and build.
- PDCN-1569(2), RTSTAT-10(1, 22 nets), LUTAR-1(2): generated AXI4-to-AXI3 HP-interconnect FIFO logic, same warning categories as V1. The physical DMA path still requires admission with the new bitstream.
- TIMING-18(5): four serial inputs and WS referenced to FCLK by the generic methodology rule. These ports have explicit generated-BCLK constraints. The independent check_timing report has zero missing input delays, zero unconstrained internal endpoints, and all 10 external setup/hold paths pass. Forwarded BCLK has no data-output delay by design. The external 420 ns input budget remains physically unmeasured.
- REQP-165/181 are write-first RAM advisories. Unused frame bits are intentional: this correlator selects MIC01/05/07/08 and right-shifts each signed24 sample by four. The retained capture path still exports all eight channels for diagnostics.

Two procedural failures are preserved separately: sim_unit_V1 stopped before Vivado because the new log directory did not exist; the wrapper was fixed before the actual simulations. The first admission attempt ran before XSA export finished and was rejected by the required TOOL_EXIT_0 gate. The build was not restarted; after its exit record appeared, the unchanged verifier passed. Command records retain both attempts.

The temporal guard does not certify signal validity alone: silence can have stable integer peaks, and is rejected by the unchanged PS quality checks. V2 board capture and controlled angular accuracy remain NOT_RUN / NOT_VALIDATED.
