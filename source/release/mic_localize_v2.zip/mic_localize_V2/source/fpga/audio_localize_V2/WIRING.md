# PYNQ-Z2 40-pin header to microphone board J1

本接线表与 `mic_rpi40.bit` / `mic_rpi40.hwh` 配套。所有数字均为连接器的**实体针号**，不是 GPIO 编号，也不是 FPGA 封装球号。

连接线为现有 2.54 mm 公对母杜邦线：母头套在 PYNQ 的 40 针公排针；公头插进麦克风板的 J1 母座。接线时关闭 PYNQ 电源。

## 每根线

| 麦克风板 J1 针号 | 信号 | PYNQ 40 针实体针号 | FPGA 封装球号 |
|---:|---|---:|---|
| 1 | BCLK | **33** | W8 |
| 2 | WS | **35** | Y8 |
| 3 | DATA0：MIC01/02 | **36** | B19 |
| 4 | DATA1：MIC03/04 | **37** | W9 |
| 5 | GND | **34** | 地 |
| 6 | 3V3 | **1** | 3.3 V 电源 |
| 7 | DATA2：MIC05/06 | **38** | A20 |
| 8 | DATA3：MIC07/08 | **40** | Y9 |
| 9 | NC | 不接 | — |
| 10 | NC | 不接 | — |
| 11 | GND | **39** | 地 |
| 12 | 3V3 | **17** | 3.3 V 电源 |

共 10 根线。40 针上的 **2、4 是 5 V，保持不接**。J1 的 6、12 虽仍标 `PMOD_3V3`，在此方案接的都是 40 针排针的 3.3 V。

## 按用户照片方向认针

PYNQ 元件面朝上、40 针排针在照片上边。**1/2 脚在右端，靠安装孔；39/40 脚在左端，靠 HDMI 接口**。

```text
板外侧 / 远离 PYNQ 字样的一排
39 37 35 33 31 29 27 25 23 21 19 17 15 13 11 09 07 05 03 01
40 38 36 34 32 30 28 26 24 22 20 18 16 14 12 10 08 06 04 02
板内侧 / 靠 PYNQ 字样的一排

左端局部：
GND DATA1  WS   BCLK
 39   37   35   33
 40   38   36   34
DATA3 DATA2 DATA0 GND
```

麦克风板元件面朝上、`PYNQ MIC FANOUT V1` 标题正向时，J1 的左上角是 1 脚（方形焊盘对应位置）。

```text
  1     2      3      4     5    6
BCLK   WS    DATA0  DATA1  GND  3V3

  7     8      9     10    11   12
DATA2 DATA3    NC    NC    GND  3V3
```

上图以元件面为准；从板背面看会左右镜像。两根地线均连接，线束尽量短，BCLK 线靠近地线。

## 与工程的对应

- 六个信号使用独立的 Raspberry Pi GPIO，不与 PMODA 共享。
- 电平 LVCMOS33；FCLK 100 MHz；BCLK 2 MHz；每声道 32 bit 时隙、24 bit 有效数据，采样率 31,250 Hz。
- 四路 SD 每路左右两个声道；DMA 按 MIC01..MIC08 顺序写入八个有符号 32 bit 字，24 bit 数据符号扩展。
- 这是离线构建交付。实体接线、焊接通断、模块输出及上板录音尚未验证。

## 引脚来源

1. TUL 修订手册 v1.1，第 27 页 Table 22：`reference/PYNQ_Z2_User_Manual_v1_1.pdf`。
2. TUL 原理图 R12 文件，第 4 页 RPI_IDE / 串联电阻映射及第 11 页 FPGA 管脚：`reference/PYNQ_Z2_Schematic_R12.pdf`。
3. 项目固定官方 Master XDC：`hardware/reference/pynq_z2_master_V1.xdc`。所选 GPIO 逐条与 `wiring.csv` 校验一致。

旧手册 v1.0 的 40 针映射存在错误，本交付不使用该表。

官方来源：
- https://dpoauwgwqsy2x.cloudfront.net/Download/PYNQ_Z2_User_Manual_v1.1.pdf
- https://dpoauwgwqsy2x.cloudfront.net/Download/TUL_PYNQ_Schematic_R12.pdf
