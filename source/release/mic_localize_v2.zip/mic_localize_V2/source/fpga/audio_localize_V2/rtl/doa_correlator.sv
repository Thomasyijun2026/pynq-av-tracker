`timescale 1ns/1ps
// Snapshot engine, all in the 100 MHz domain. One product per three cycles.
// The selected frame order is MIC01,05,07,08. No serial-slot timing correction.
module doa_correlator #(
    parameter integer WINDOW_FRAMES=32768,
    parameter integer SKIP_FRAMES=31250
)(
    input wire clk, resetn, arm, abort_capture,
    input wire sample_valid,
    input wire [255:0] frame_data,
    input wire [7:0] read_index,
    output wire [63:0] read_data,
    output reg ready, active, overrun,
    output reg [31:0] accumulated_frames,
    output wire [47:0] peak_lags,
    output reg [191:0] subwindow_peaks,
    output reg [3:0] temporal_match_mask,
    output reg [2:0] temporal_support,
    output reg temporal_stable
);
    localparam SUBWINDOW_FRAMES=WINDOW_FRAMES/4;
    localparam IDLE=0, READ_OP=1, MULTIPLY=2, ACCUMULATE=3, PEAK_READ=4, PEAK_COMPARE=5, FINISH=6;
    reg [2:0] state;
    reg [31:0] skipped, history_samples;
    reg [5:0] wr_ptr, center_ptr;
    reg [7:0] term_addr;
    reg [2:0] pair_index;
    reg [5:0] lag_index;
    reg signed [19:0] previous1[0:3], previous2[0:3], previous3[0:3];
    wire signed [19:0] input_word[0:3];
    wire signed [21:0] filtered[0:3];
    (* ram_style="distributed" *) reg signed [21:0] history[0:3][0:63];
    (* ram_style="distributed" *) reg signed [63:0] sums[0:201];
    (* ram_style="distributed" *) reg signed [63:0] sub_sums[0:197];
    reg [31:0] sub_frames;
    reg [1:0] sub_index;
    reg scanning_full;
    reg signed [21:0] operand_a, operand_b;
    (* use_dsp="yes" *) reg signed [43:0] product;
    wire signed [63:0] extended_product={{20{product[43]}},product};
    reg [63:0] peak_value, candidate;
    reg [5:0] peak_index;
    reg signed [7:0] peaks[0:5];
    wire [5:0] lag_address=center_ptr+lag_index-6'd16;
    wire [1:0] energy_channel=term_addr-8'd198;
    wire [3:0] guard_mask;
    wire [2:0] guard_support;
    wire guard_stable;
    doa_temporal_guard guard(.full_peaks(peak_lags),.sub_peaks(subwindow_peaks),
        .match_mask(guard_mask),.support(guard_support),.stable(guard_stable));
    assign read_data=(ready && read_index<202) ? sums[read_index] : 64'd0;
    assign peak_lags={peaks[5],peaks[4],peaks[3],peaks[2],peaks[1],peaks[0]};
    assign input_word[0]=$signed(frame_data[0*32 +: 32]) >>> 4;
    assign input_word[1]=$signed(frame_data[4*32 +: 32]) >>> 4;
    assign input_word[2]=$signed(frame_data[6*32 +: 32]) >>> 4;
    assign input_word[3]=$signed(frame_data[7*32 +: 32]) >>> 4;
    genvar g;
    generate for(g=0;g<4;g=g+1) begin: fir
        assign filtered[g]=$signed({{2{input_word[g][19]}},input_word[g]})
            +$signed({{2{previous1[g][19]}},previous1[g]})
            -$signed({{2{previous2[g][19]}},previous2[g]})
            -$signed({{2{previous3[g][19]}},previous3[g]});
    end endgenerate
    function automatic [1:0] channel_i(input [2:0] p);
        case(p) 0,1,2:channel_i=0; 3,4:channel_i=1; default:channel_i=2; endcase
    endfunction
    function automatic [1:0] channel_j(input [2:0] p);
        case(p) 0:channel_j=1; 1,3:channel_j=2; default:channel_j=3; endcase
    endfunction
    function automatic [63:0] magnitude(input signed [63:0] value);
        magnitude=value[63] ? -value : value;
    endfunction
    integer c;
    always @(posedge clk) begin
        if(!resetn || arm) begin
            ready<=0;active<=resetn && arm;overrun<=0;accumulated_frames<=0;
            skipped<=0;history_samples<=0;wr_ptr<=0;center_ptr<=0;
            sub_frames<=0;sub_index<=0;scanning_full<=0;subwindow_peaks<=0;
            temporal_match_mask<=0;temporal_support<=0;temporal_stable<=0;
            state<=IDLE;term_addr<=0;pair_index<=0;lag_index<=0;
            operand_a<=0;operand_b<=0;product<=0;peak_value<=0;candidate<=0;peak_index<=0;
            for(c=0;c<4;c=c+1) begin previous1[c]<=0;previous2[c]<=0;previous3[c]<=0;end
            for(c=0;c<6;c=c+1) peaks[c]<=0;
            // RAM is intentionally not reset: first accumulation overwrites every address.
        end else if(abort_capture && !ready) begin
            active<=0;state<=IDLE;
        end else begin
            if(sample_valid && active) begin
                if(state!=IDLE) overrun<=1;
                if(skipped<SKIP_FRAMES) skipped<=skipped+1;
                else begin
                    for(c=0;c<4;c=c+1) begin
                        history[c][wr_ptr]<=filtered[c];
                        previous3[c]<=previous2[c];previous2[c]<=previous1[c];previous1[c]<=input_word[c];
                    end
                    wr_ptr<=wr_ptr+1'b1;
                    history_samples<=history_samples+1;
                    if(history_samples>=35 && state==IDLE) begin
                        center_ptr<=wr_ptr-6'd16;term_addr<=0;pair_index<=0;lag_index<=0;state<=READ_OP;
                    end
                end
            end
            case(state)
                READ_OP: begin
                    if(term_addr<198) begin
                        operand_a<=history[channel_i(pair_index)][center_ptr];
                        operand_b<=history[channel_j(pair_index)][lag_address];
                    end else begin
                        operand_a<=history[energy_channel][center_ptr];
                        operand_b<=history[energy_channel][center_ptr];
                    end
                    state<=MULTIPLY;
                end
                MULTIPLY: begin product<=operand_a*operand_b;state<=ACCUMULATE;end
                ACCUMULATE: begin
                    sums[term_addr]<=(accumulated_frames==0 ? 64'sd0 : sums[term_addr])+extended_product;
                    if(term_addr<198)
                        sub_sums[term_addr]<=(sub_frames==0 ? 64'sd0 : sub_sums[term_addr])+extended_product;
                    if(term_addr==201) begin
                        accumulated_frames<=accumulated_frames+1;
                        if(accumulated_frames==WINDOW_FRAMES-1) active<=0;
                        if(sub_frames==SUBWINDOW_FRAMES-1) begin
                            sub_frames<=0;scanning_full<=0;
                            state<=PEAK_READ;term_addr<=0;pair_index<=0;lag_index<=0;
                            peak_value<=0;peak_index<=0;
                        end else begin sub_frames<=sub_frames+1;state<=IDLE;end
                    end else begin
                        term_addr<=term_addr+1;
                        if(lag_index==32) begin lag_index<=0;pair_index<=pair_index+1;end
                        else lag_index<=lag_index+1;
                        state<=READ_OP;
                    end
                end
                PEAK_READ: begin
                    candidate<=magnitude(scanning_full ? sums[term_addr] : sub_sums[term_addr]);
                    state<=PEAK_COMPARE;
                end
                PEAK_COMPARE: begin
                    if(candidate>peak_value) begin peak_value<=candidate;peak_index<=lag_index;end
                    if(lag_index==32) begin
                        if(scanning_full)
                            peaks[pair_index]<=$signed({2'b0,(candidate>peak_value ? lag_index : peak_index)})-8'sd16;
                        else
                            subwindow_peaks[sub_index*48+pair_index*8+:8]<=
                                $signed({2'b0,(candidate>peak_value ? lag_index : peak_index)})-8'sd16;
                        if(pair_index==5) begin
                            if(scanning_full) state<=FINISH;
                            else if(accumulated_frames==WINDOW_FRAMES) begin
                                scanning_full<=1;state<=PEAK_READ;
                                pair_index<=0;lag_index<=0;term_addr<=0;peak_value<=0;peak_index<=0;
                            end else begin sub_index<=sub_index+1;state<=IDLE;end
                        end
                        else begin
                            pair_index<=pair_index+1;lag_index<=0;term_addr<=term_addr+1;
                            peak_value<=0;peak_index<=0;state<=PEAK_READ;
                        end
                    end else begin lag_index<=lag_index+1;term_addr<=term_addr+1;state<=PEAK_READ;end
                end
                FINISH: begin
                    temporal_match_mask<=guard_mask;temporal_support<=guard_support;
                    temporal_stable<=guard_stable && !overrun;
                    ready<=!overrun;state<=IDLE;
                end
                default: ;
            endcase
        end
    end
endmodule
