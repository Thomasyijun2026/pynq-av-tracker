param([Parameter(Mandatory)][ValidateSet('simulate','build')][string]$Task,
      [Parameter(Mandatory)][string]$RunName,
      [ValidateSet('mic_capture_tb','doa_correlator_tb')][string]$SimTop='mic_capture_tb')
$ErrorActionPreference='Stop'
$root='D:\pynq_av_localizer'
if($RunName -notmatch '^[a-zA-Z0-9_]+$'){throw 'ASCII run name required'}
$src=Join-Path $root 'fpga\audio_localize_V2'
$run=Join-Path $root "build\mic_localize_V2\$RunName"
$logs=Join-Path $root 'logs\mic_localize_V2'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
$log=Join-Path $logs "$RunName.console.log"
if((Test-Path -LiteralPath $run) -or (Test-Path -LiteralPath $log)){throw 'Run already exists; select a new version'}
New-Item -ItemType Directory -Path $run -Force | Out-Null
$env:TEMP=Join-Path $root 'build\mic_localize_V2\tmp'
New-Item -ItemType Directory -Path $env:TEMP -Force | Out-Null
$env:TMP=$env:TEMP
$env:PYTHONDONTWRITEBYTECODE='1'
# Use the project logger and its named mutex without changing PowerShell policy.
$common=Join-Path $root 'scripts\common.ps1'
$tokens=$null;$parseErrors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseFile($common,[ref]$tokens,[ref]$parseErrors)
$logger=$ast.Find({param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Write-CommandRecord'},$true)
if(!$logger -or $parseErrors.Count){throw 'Cannot load project command logger'}
. ([scriptblock]::Create($logger.Extent.Text))
$exe='D:\Vivado2026.1\2026.1\Vivado\bin\vivado.bat'
$toolArgs=@('-mode','batch','-nojournal','-log',(Join-Path $logs "$RunName.vivado.log"),'-source',(Join-Path $src "tcl\$Task.tcl"),'-tclargs',$run)
if($Task -eq 'simulate'){$toolArgs += $SimTop}
$rec=[ordered]@{time=(Get-Date).ToString('o');task=$Task;run=$RunName;pid=$PID;executable=$exe;arguments=$toolArgs;working_directory=$run;log=$log;state='STARTED';exit_code=$null}
Write-CommandRecord -Record $rec -Path (Join-Path $logs 'commands.jsonl')
Push-Location -LiteralPath $run
try {
  $ErrorActionPreference='Continue'
  & $exe @toolArgs *> $log
  $code=$LASTEXITCODE
} finally { Pop-Location }
$rec.state=if($code -eq 0){'TOOL_EXIT_0'}else{'FAIL'}
$rec.exit_code=$code;$rec['finished']=(Get-Date).ToString('o')
Write-CommandRecord -Record $rec -Path (Join-Path $logs 'commands.jsonl')
Write-Output "run=$RunName exit=$code log=$log"
exit $code
