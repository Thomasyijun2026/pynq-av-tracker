"""Read-only build admission; records checked facts without packaging or board I/O."""
from pathlib import Path
import datetime,hashlib,json,re,xml.etree.ElementTree as ET,zipfile
ROOT=Path(__file__).resolve().parents[3]
SRC=ROOT/'fpga/audio_localize_V2'
LOG=ROOT/'logs/mic_localize_V2';RUN=ROOT/'build/mic_localize_V2/build_V1'
REPORT=RUN/'reports';OUT=RUN/'output'
def text(p):return p.read_text(encoding='utf-8',errors='replace')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(ok,message):
    if not ok:raise RuntimeError(message)
def table_rules(name):
    rules={}
    for line in text(REPORT/name).splitlines():
        cells=[c.strip() for c in line.split('|')]
        if len(cells)==6 and re.fullmatch(r'[A-Z]+-\d+',cells[1]):
            rules[cells[1]]={'severity':cells[2],'description':cells[3],'count':int(cells[4])}
    need(all(v['severity'] not in ('Error','Critical Warning') for v in rules.values()),name+' severe finding')
    return rules
records=[json.loads(line) for line in text(LOG/'commands.jsonl').splitlines()]
for name in ['sim_unit_V2','sim_interface_V1','build_V1']:
    done=[r for r in records if r['run']==name and r['state']=='TOOL_EXIT_0']
    need(len(done)==1 and done[0]['exit_code']==0,name+' incomplete')
need('DOA_CORRELATOR_TEST_PASS checks=8100' in text(LOG/'sim_unit_V2.console.log'),'Unit simulation marker missing')
need('MIC_CAPTURE_TEST_PASS checks=721830' in text(LOG/'sim_interface_V1.console.log'),'Integration simulation marker missing')
need('\nMIC_LOCALIZE_BUILD_PASS\n' in text(LOG/'build_V1.console.log').replace('\r\n','\n'),'Build marker missing')
manifest=json.loads(text(ROOT/'logs/mic_stability_V2/build_source_manifest.json'))
sources={k:v for k,v in manifest['files'].items() if k.startswith('fpga/')}
need(all(sha(ROOT/k)==v for k,v in sources.items()),'Build source changed')
metrics={k:float(v) for k,v in (line.split('\t') for line in text(REPORT/'timing_metrics.tsv').splitlines())}
need(metrics['setup_slack_ns']>=0 and metrics['hold_slack_ns']>=0 and metrics['clock_count']==2,'Timing failure')
need('All user specified timing constraints are met.' in text(REPORT/'timing_summary.rpt'),'Timing summary failure')
check=text(REPORT/'check_timing.rpt')
for category in ['no_clock','unconstrained_internal_endpoints','no_input_delay','partial_input_delay','partial_output_delay','generated_clocks','loops','latch_loops']:
    need('checking '+category+' (0)' in check,'Timing check '+category)
need('checking no_output_delay (1)' in check and '\nmic_bclk\n' in check.replace('\r\n','\n'),'Unexpected missing data output delay')
need(re.search(r'Info\s+mic_bclk\s+clk_fpga_0\s+Safely Timed\s+None\s+4\s+4\s+0\s+0\s+0',text(REPORT/'cdc.rpt')),'CDC mismatch')
external={}
for filename in ['serial_input_timing.rpt','ws_output_timing.rpt']:
    slacks=[(s,float(v)) for s,v in re.findall(r'Slack \((\w+)\)\s*:\s*([-\d.]+)ns',text(REPORT/filename))]
    need(len(slacks)==(8 if filename.startswith('serial') else 2),'External timing path count')
    need(all(s=='MET' and v>=0 for s,v in slacks),'External timing failure')
    external[filename]={'paths':len(slacks),'minimum_slack_ns':min(v for s,v in slacks)}
io=text(REPORT/'io.rpt')
pinmap=json.loads(text(SRC/'pinmap.json'))
for pin in [p for p in pinmap if p['hdl_port']]:
    rows=[l for l in io.splitlines() if re.search(r'\|\s*'+re.escape(pin['hdl_port'])+r'\s*\|',l)]
    need(len(rows)==1,'Pin missing')
    c=[s.strip() for s in rows[0].split('|')]
    need(c[1]==pin['fpga_pin'] and c[6]=='LVCMOS33','Pin/standard mismatch')
drc=table_rules('drc.rpt');methodology=table_rules('methodology.rpt')
hwh=ET.parse(OUT/'mic_localize.hwh').getroot()
need(hwh.get('VIVADOVERSION')=='2026.1','Tool mismatch')
modules={m.get('INSTANCE'):m for m in hwh.findall('.//MODULE')}
expected={'ps7':{'PCW_ACT_FPGA0_PERIPHERAL_FREQMHZ':'100.000000','PCW_UIPARAM_DDR_BUS_WIDTH':'16 Bit','PCW_USE_S_AXI_HP0':'1'},
          'axi_dma_0':{'C_INCLUDE_MM2S':'0','C_INCLUDE_S2MM':'1','C_INCLUDE_SG':'0','C_M_AXI_S2MM_DATA_WIDTH':'64','C_S_AXIS_S2MM_TDATA_WIDTH':'32','C_SG_LENGTH_WIDTH':'26'},
          'mic_capture_0':{'WARMUP_FRAMES':'4096','FIFO_LOG2':'4','DOA_WINDOW_FRAMES':'32768','DOA_SKIP_FRAMES':'31250'}}
for name,expect in expected.items():
    params={p.get('NAME'):p.get('VALUE') for p in modules[name].findall('./PARAMETERS/PARAMETER')}
    need(all(params.get(k)==v for k,v in expect.items()),'HWH config mismatch '+name+' '+repr(params))
addresses={p.get('INSTANCE'):p.get('BASEVALUE') for p in hwh.findall('.//MEMRANGE')}
need(addresses['mic_capture_0']=='0x43C00000' and addresses['axi_dma_0']=='0x40400000','HWH address mismatch')
with zipfile.ZipFile(OUT/'mic_localize.xsa') as z:
    need(z.testzip() is None,'XSA CRC failure')
    for ext in ['bit','hwh']:
        members=[n for n in z.namelist() if n.endswith('.'+ext)]
        need(len(members)==1 and z.read(members[0])==(OUT/('mic_localize.'+ext)).read_bytes(),'XSA file mismatch')
resources={}
for name in ['Slice LUTs','Slice Registers','Block RAM Tile','DSPs']:
    m=re.search(r'\|\s*'+re.escape(name)+r'\s*\|\s*([\d.]+)',text(REPORT/'utilization.rpt'))
    need(m is not None,'Resource row missing');resources[name]=float(m.group(1))
out={'status':'OFFBOARD_PASS','pc_time':datetime.datetime.now().astimezone().isoformat(),'timing':metrics,
     'resources':resources,'external_timing':external,'drc':drc,'methodology':methodology,
     'source_sha256':sources,'artifacts':{f.name:sha(f) for f in OUT.glob('*') if f.is_file()},
     'unit_checks':8100,'interface_checks':721830,'xsa_crc_and_bit_hwh':'PASS','cdc':'4 safely timed, 0 unsafe/unknown',
     'board_validation':'NOT_RUN','physical_accuracy':'NOT_VALIDATED','external_timing_assumptions':'Unmeasured; unchanged original420ns input budget'}
with (LOG/'build_verification.json').open('x') as f:json.dump(out,f,indent=2)
print(json.dumps({k:out[k] for k in ['status','timing','resources','drc','methodology']}))
