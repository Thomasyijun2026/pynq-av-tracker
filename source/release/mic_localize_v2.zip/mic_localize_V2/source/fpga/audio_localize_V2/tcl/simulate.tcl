set source_root [file normalize [file join [file dirname [info script]] ..]]
set run_dir [file normalize [lindex $argv 0]]
set top [lindex $argv 1]
if {$top ni {doa_correlator_tb mic_capture_tb}} {error "Explicit supported top required"}
set marker [expr {$top eq "doa_correlator_tb" ? "DOA_CORRELATOR_TEST_PASS" : "MIC_CAPTURE_TEST_PASS"}]
# One project per Vivado process avoids stale XSim properties in Vivado2026.1.
    set case_dir [file join $run_dir $top]
    create_project mic_sim $case_dir -part xc7z020clg400-1 -force
    add_files [glob $source_root/rtl/*.sv]
    add_files -fileset sim_1 $source_root/sim/${top}.sv
    set_property top $top [get_filesets sim_1]
    set_property xsim.simulate.runtime all [get_filesets sim_1]
    set_property xsim.simulate.log_all_signals false [get_filesets sim_1]
    set_property xsim.elaborate.mt_level off [get_filesets sim_1]
    launch_simulation -simset sim_1 -mode behavioral -step compile
    launch_simulation -simset sim_1 -mode behavioral -step elaborate
    set saved_dir [pwd]
    cd $case_dir/mic_sim.sim/sim_1/behav/xsim
    foreach file [glob $source_root/sim/vectors/*.hex] {file copy $file [file tail $file]}
    set transcript [exec cmd.exe /c D:/Vivado2026.1/2026.1/Vivado/bin/xsim.bat ${top}_behav -runall -log standalone.log 2>@1]
    puts $transcript
    cd $saved_dir
    if {[string first $marker $transcript] < 0} {error "Test PASS marker missing for $top"}
    close_project
puts "LOCALIZE_SIM_TOOL_COMPLETED"
