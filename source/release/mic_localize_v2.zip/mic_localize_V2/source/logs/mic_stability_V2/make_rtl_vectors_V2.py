from pathlib import Path
import hashlib,json,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'software/pynq/mic_doa_V2'))
from pl_reference import features
target=ROOT/'fpga/audio_localize_V2/sim/vectors'
rng=np.random.default_rng(281128)
short_n=256+35+8
cases=[('random_int24',rng.integers(-8388608,8388608,(short_n,8),dtype=np.int64),256,8),
       ('silence',np.zeros((short_n,8),dtype=np.int64),256,8),
       ('dc',np.full((short_n,8),123456,dtype=np.int64),256,8)]
edge=np.zeros((short_n,8),dtype=np.int64)
for ch in range(8):edge[:,ch]=np.where(((np.arange(short_n)+ch)//2)%2,-8388608,8388607)
cases.append(('signed_limits',edge,256,8))
for rd,cap,wi,name in [(5,1,0,'short_recorded'),(6,3,2,'jump006'),(13,5,3,'jump013'),(13,5,2,'stable013')]:
    run=ROOT/f'logs/mic_monitor_V1/round_{rd:03d}'
    v=json.loads((run/f'verification_{cap:02d}.json').read_text())
    rp=run/'results'/v['capture']/'raw_i32le.bin'
    assert hashlib.sha256(rp.read_bytes()).hexdigest()==v['raw_sha256']
    a=np.fromfile(rp,dtype='<i4').reshape(-1,8)
    window,skip=(256,8) if name=='short_recorded' else (32768,0)
    start=31250+wi*32768
    cases.append((name,a[start:start+window+35+skip].astype(np.int64),window,skip))
manifest=[]
for idx,(name,x,window,skip) in enumerate(cases):
    snap=features(x[skip:,[0,4,6,7]],window)
    with (target/f'case{idx}_input.hex').open('x') as f:
        for row in x:f.write(''.join(f'{int(v)&0xffffffff:08x}' for v in row[::-1])+'\n')
    with (target/f'case{idx}_expected.hex').open('x') as f:
        for value in snap['sums_i64']:f.write(f'{value&0xffffffffffffffff:016x}\n')
    with (target/f'case{idx}_peaks.hex').open('x') as f:
        for group in [snap['integer_peaks']]+snap['subwindow_peaks']:
            f.write(''.join(f'{v&255:02x}' for v in group[::-1])+'\n')
    # Separate 198-word oracle at every subwindow boundary; full energies above.
    a=x[skip:,[0,4,6,7]]>>4
    pad=np.pad(a,((3,0),(0,0)))
    y=pad[3:]+pad[2:-1]-pad[1:-2]-pad[:-3]
    import itertools
    with (target/f'case{idx}_sub_sums.hex').open('x') as f:
        for q in range(4):
            s=19+q*(window//4)
            for i,j in itertools.combinations(range(4),2):
                for lag in range(-16,17):
                    v=int(np.dot(y[s:s+window//4,i],y[s+lag:s+lag+window//4,j]))
                    f.write(f'{v&0xffffffffffffffff:016x}\n')
    g=snap['guard'];bits=(g['support']<<5)|(g['match_mask']<<1)|int(g['stable'])
    (target/f'case{idx}_guard.hex').write_text(f'{bits:02x}\n')
    manifest.append({'index':idx,'name':name,'frames':len(x),'window':window,'skip':skip,'guard':g})
out={'cases':manifest,'file_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in target.glob('*.hex')}}
with (Path(__file__).parent/'rtl_vectors_V2.json').open('x') as f:json.dump(out,f,indent=2)
print('V2_RTL_VECTORS_CREATED',len(cases),'cases including both full anomalous windows and stable neighbor')
