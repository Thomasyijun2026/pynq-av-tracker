"""Create a deterministic 20-second broadband source for controlled tests."""
from pathlib import Path
import hashlib,json,wave
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
DEST=ROOT/'release/mic_test_source_V1'
DEST.mkdir()
rate=48000;seconds=20;n=rate*seconds
rng=np.random.default_rng(20261028)
freq=np.fft.rfftfreq(n,1/rate)
spec=np.fft.rfft(rng.normal(size=n))
spec[(freq<300)|(freq>6000)]=0
x=np.fft.irfft(spec,n)
x*=.08/np.std(x)
fade=round(.25*rate)
x[:fade]*=np.linspace(0,1,fade);x[-fade:]*=np.linspace(1,0,fade)
assert np.max(np.abs(x))<.8
pcm=np.rint(x*32767).astype('<i2')
path=DEST/'broadband_20s_V1.wav'
with wave.open(str(path),'wb') as wav:
    wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(rate);wav.writeframes(pcm.tobytes())
with wave.open(str(path),'rb') as wav:
    assert wav.getnchannels()==1 and wav.getframerate()==rate and wav.getnframes()==n
    assert wav.readframes(n)==pcm.tobytes()
measured=np.fft.rfft(pcm.astype(float))
band=(freq>=300)&(freq<=6000)
power_fraction=float(np.sum(abs(measured[band])**2)/np.sum(abs(measured)**2))
assert power_fraction>.99
out={'status':'AUDIO_FILE_CHECK_PASS','rate_hz':rate,'seconds':seconds,'channels':1,'pcm_bits':16,
     'passband_hz':[300,6000],'band_power_fraction':power_fraction,
     'normalized_rms':float(np.std(pcm)/32768),'normalized_peak':float(np.max(abs(pcm.astype(int)))/32768),
     'seed':20261028,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
     'scope':'Digital source file only; speaker/acoustic output not yet measured'}
with (DEST/'manifest.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2)
print(json.dumps(out))
