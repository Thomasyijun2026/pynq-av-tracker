"""Frozen V2 guard versus every retained raw capture and declared synthetic cases."""
from pathlib import Path
import hashlib, itertools, json, sys
from datetime import datetime
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'software/pynq/mic_doa_V2'))
from pl_reference import features, estimate, peak_guard, WINDOW
from baseline_V1 import features as baseline_features, estimate as baseline_estimate
from direction import read_positions
coords=read_positions(ROOT/'hardware/mic_fanout_v1/exports/component_coordinates_V20.csv',[1,5,7,8])
failures=[]

def need(condition, message):
    if not condition: failures.append(message)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def err(a,b):return abs((a-b+180)%360-180)

rng=np.random.default_rng(281008)
n=65536
freq=np.fft.rfftfreq(n,1/31250)
def source(deg, noise=0, seed_rng=rng):
    spec=np.fft.rfft(seed_rng.normal(size=n))
    spec[(freq<250)|(freq>6500)]=0
    u=np.array([np.sin(np.deg2rad(deg)),np.cos(np.deg2rad(deg))])*.8
    delays=np.array([-coords[c]@u*31250/343 for c in [1,5,7,8]])
    x=np.column_stack([np.fft.irfft(spec*np.exp(-2j*np.pi*np.fft.rfftfreq(n)*d),n)*g
                       for d,g in zip(delays,[1.,.7,1.4,-.9])])
    x+=seed_rng.normal(size=x.shape)*noise
    return np.rint(x*100000).astype(np.int64),delays

def check_signal(name,x,expect_valid,truth=None):
    snap=features(x)
    need(np.array_equal(snap['sums_i64'],baseline_features(x)),name+': baseline features')
    result=estimate(snap,coords)
    need(result['valid']==expect_valid,name+': acceptance')
    if truth is not None and result['valid']:
        need(err(result['bearing_deg'],truth)<2.,name+': bearing accuracy')
    return {'name':name,'expected_valid':expect_valid,'truth':truth,'result':result,
            'subwindow_peaks':snap['subwindow_peaks']}

synthetic=[]
for deg in [-175,-135,-90,-60,-30,0,30,60,90,135,175]:
    for noise in [0.,.1]:
        x,delays=source(deg,noise)
        record=check_signal(f'direction_{deg}_noise_{noise}',x,True,deg)
        lagtruth=[delays[j]-delays[i] for i,j in itertools.combinations(range(4),2)]
        lagerr=float(np.max(np.abs(np.array(record['result'].get('lags',[999]*6))-lagtruth)))
        need(lagerr<.12,record['name']+': lag error')
        record['max_lag_error_samples']=lagerr
        synthetic.append(record)
synthetic.append(check_signal('silence',np.zeros((WINDOW+35,4),dtype=np.int64),False))
synthetic.append(check_signal('independent',rng.integers(-10000,10001,(WINDOW+35,4)),False))
synthetic.append(check_signal('identical',np.repeat(rng.integers(-10000,10001,(WINDOW+35,1)),4,axis=1),False))
t=np.arange(WINDOW+35)/31250
delays=np.array([-coords[c]@np.array([.3,.6])/343 for c in [1,5,7,8]])
for frequency in [125,250,500,1000,2000,4000,7000]:
    x=np.rint(np.sin(2*np.pi*frequency*(t[:,None]-delays))*100000).astype(np.int64)
    synthetic.append(check_signal(f'pure_tone_{frequency}',x,False))
x,_=source(40)
for ch in range(4):
    y=x.copy();y[:,ch]=0
    synthetic.append(check_signal(f'dead_channel_{ch}',y,False))
for deg in [-135,-45,45,135]:
    x,_=source(deg,.03)
    # Strong level modulation, no directional change; includes a tenfold level burst.
    gains=np.repeat([.2,2.,.7,1.],WINDOW//4)
    envelope=np.ones(n);envelope[19:19+WINDOW]=gains
    y=np.rint(x*envelope[:,None]).astype(np.int64)
    synthetic.append(check_signal(f'level_modulation_{deg}',y,True,deg))
for first,second in [(-60,75),(75,-60),(-135,30),(30,-135)]:
    x,_=source(first,.03);y,_=source(second,.03)
    z=x.copy();z[19+WINDOW//2:]=y[19+WINDOW//2:]
    synthetic.append(check_signal(f'transition_{first}_{second}',z,False))
    synthetic.append(check_signal(f'post_transition_{first}_{second}',y,True,second))

# Pure guard arithmetic covers exact one/two-sample boundary and every mask.
guard_cases=[]
for mask in range(16):
    q=np.zeros((4,6),dtype=int)
    for i in range(4):q[i,0]=1 if mask&(1<<i) else 2
    g=peak_guard([0]*6,q)
    need(g['match_mask']==mask and g['stable']==(mask.bit_count()>=3),f'guard_mask_{mask}')
    guard_cases.append({'mask':mask,'result':g})

raw_records=[]
for rd in sorted((ROOT/'logs/mic_monitor_V1').glob('round_[0-9][0-9][0-9]')):
    for vf in sorted(rd.glob('verification_*.json')):
        old=json.loads(vf.read_text())
        rp=rd/'results'/old['capture']/'raw_i32le.bin'
        need(sha(rp)==old['raw_sha256'],str(rp)+': raw hash')
        raw=np.fromfile(rp,dtype='<i4').reshape(-1,8)[:,[0,4,6,7]]
        windows=[]
        for wi,saved in enumerate(old['offline_fixed_point_windows']):
            start=31250+wi*WINDOW
            segment=raw[start:start+WINDOW+35]
            snap=features(segment)
            v1=baseline_features(segment)
            need(np.array_equal(snap['sums_i64'],v1),old['capture']+f'/{wi}: 202 sums')
            need(baseline_estimate(v1,coords)==saved,old['capture']+f'/{wi}: saved V1 estimate')
            result=estimate(snap,coords)
            need(not result['valid'] or saved['valid'],old['capture']+f'/{wi}: old rejection preserved')
            windows.append({'index':wi,'baseline_valid':saved['valid'],
                            'baseline_angle':saved.get('fit',{}).get('bearing_deg_from_plus_y_toward_plus_x'),
                            'snapshot':snap,'V2':result})
        raw_records.append({'round':rd.name,'verification':str(vf.relative_to(ROOT)),
                            'raw':str(rp.relative_to(ROOT)),'raw_sha256':old['raw_sha256'],
                            'windows':windows})
    print('REPLAY',rd.name,'completed',len(raw_records),'captures',flush=True)

all_windows=[(r,w) for r in raw_records for w in r['windows']]
new_rejects=[{'capture':r['raw'],'window':w['index'],'candidate':w['baseline_angle'],
             'mask':w['snapshot']['guard']['match_mask'],'support':w['snapshot']['guard']['support']}
             for r,w in all_windows if w['baseline_valid'] and not w['V2']['valid']]
old_count=sum(w['baseline_valid'] for r,w in all_windows)
new_count=sum(w['V2']['valid'] for r,w in all_windows)
jumps=[]
for round_name,cap,wi in [('round_006','verification_03.json',2),('round_013','verification_05.json',3)]:
    rec=next(r for r in raw_records if r['round']==round_name and r['verification'].endswith(cap))
    w=rec['windows'][wi]
    need(w['baseline_valid'] and not w['V2']['valid'],round_name+': jump rejection')
    jumps.append({'round':round_name,'capture':cap,'window':wi,'guard':w['snapshot']['guard']})
need(len(raw_records)==122 and len(all_windows)==976 and old_count==941,'dataset completeness')
need(new_count/939>=.95,'normal acceptance coverage <95%')
angles=[w['V2']['bearing_deg'] for r,w in all_windows if w['V2']['valid']]
summary={'status':'PASS' if not failures else 'FAIL','raw_captures':len(raw_records),
         'windows':len(all_windows),'baseline_accepted':old_count,'V2_accepted':new_count,
         'baseline_rejects_preserved':len(all_windows)-old_count,
         'additional_rejections':len(new_rejects),'retained_other_accepted_fraction':new_count/939,
         'jumps':jumps,'synthetic_cases':len(synthetic),'guard_masks':len(guard_cases),
         'accepted_angles_min_max':[min(angles),max(angles)],
         'accepted_angles_mean_std':[float(np.mean(angles)),float(np.std(angles))],
         'failures':failures,'physical_accuracy':'NOT_VALIDATED'}
result={'pc_time':datetime.now().astimezone().isoformat(),'summary':summary,
        'source_hashes':{str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'software/pynq/mic_doa_V2').glob('*.py')},
        'protocol_sha256':sha(ROOT/'docs/mic_stability_V2.md'),
        'synthetic':synthetic,'guard_arithmetic':guard_cases,'newly_rejected':new_rejects,'recordings':raw_records}
with (HERE/'reference_regression_V2.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(summary,indent=2))
assert not failures,failures
