"""Exercise the V2 verifier with a clearly marked offline fixture and mutations."""
from pathlib import Path
import copy, hashlib, json, os, sys
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'software/pynq/mic_doa_V2'
sys.path.insert(0,str(SRC))
from pl_reference import features, estimate
from direction import read_positions
from verify_capture import verify
origin=ROOT/'logs/mic_localize_cli_V1/results/standalone_pl_V1'
fixture=ROOT/'build/mic_localize_V2/verifier_fixture_V1'
fixture.mkdir()
(fixture/'FIXTURE_ONLY.txt').write_text('V1 recording plus generated V2 reference fields. Never a V2 hardware observation.\n')
os.link(origin/'raw_i32le.bin',fixture/'raw_i32le.bin')
meta=json.loads((origin/'metadata.json').read_text())
old=json.loads((origin/'pl_snapshot.json').read_text())
data=(fixture/'raw_i32le.bin').read_bytes()
assert hashlib.sha256(data).hexdigest()==meta['raw_sha256']
raw=np.frombuffer(data,dtype='<i4').reshape(-1,8)
coords=ROOT/'hardware/mic_fanout_v1/exports/component_coordinates_V20.csv'
snap=copy.deepcopy(old);snap.update(features(raw[31250:,[0,4,6,7]]))
snap['extension_abi']='0x444f4102'
snap['ps_estimate']=estimate(snap,read_positions(coords,[1,5,7,8]))
(fixture/'metadata.json').write_text(json.dumps(meta),encoding='utf-8')
def save(s): (fixture/'pl_snapshot.json').write_text(json.dumps(s),encoding='utf-8')
save(snap)
out=verify(fixture,old['artifacts_sha256'],coords,len(raw))
assert out['exact_i64_features']==202 and out['exact_subwindow_peaks']==24 and out['temporal_guard_match']
checked=['unmodified_offline_fixture']
for name in ['old_abi','sum','full_peak','sub_peak','guard','ps_valid','ps_reasons']:
    modified=copy.deepcopy(snap)
    if name=='old_abi':modified['extension_abi']='0x444f4101'
    if name=='sum':modified['sums_i64'][0]+=1
    if name=='full_peak':modified['integer_peaks'][0]+=1
    if name=='sub_peak':modified['subwindow_peaks'][0][0]+=1
    if name=='guard':modified['guard']['stable']=not modified['guard']['stable']
    if name=='ps_valid':modified['ps_estimate']['valid']=not modified['ps_estimate']['valid']
    if name=='ps_reasons':modified['ps_estimate']['reasons'].append('test_mutation')
    save(modified)
    try:verify(fixture,old['artifacts_sha256'],coords,len(raw))
    except (AssertionError,ValueError):checked.append(name)
    else:raise AssertionError('Failed to reject '+name)
save(snap)
assert hashlib.sha256((origin/'raw_i32le.bin').read_bytes()).hexdigest()==meta['raw_sha256']
result={'status':'OFFLINE_VERIFIER_TEST_PASS','checks':len(checked),'cases':checked,
        'physical_accuracy':'NOT_VALIDATED','V2_board_validation':'NOT_RUN',
        'fixture_scope':'Old V1 measured raw/metadata with generated V2 reference, only for testing the verifier',
        'source_sha256':{n:hashlib.sha256((SRC/n).read_bytes()).hexdigest() for n in ['verify_capture.py','delay.py','analyze_recording.py']}}
with (ROOT/'logs/mic_stability_V2/capture_verifier_tests_V2.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
