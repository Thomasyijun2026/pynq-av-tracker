"""Offline ABI2 reader and manifest failure tests; no PYNQ import or I/O."""
from pathlib import Path
import copy, hashlib, json, sys
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'software/pynq/mic_doa_V2'
sys.path.insert(0,str(SRC))
from pl_reference import features, peak_guard
from pl_snapshot import read_snapshot
import run_localizer_V2 as cli
checks=[]
def ok(name, cond):
    assert cond,name
    checks.append(name)
def bad(name, fn):
    try: fn()
    except (ValueError,RuntimeError,FileExistsError): checks.append(name)
    else: raise AssertionError(name+' unexpectedly accepted')
def pack(lags):return sum((int(v)&255)<<(8*i) for i,v in enumerate(lags))
class Registers:
    def __init__(self, snap, window=256):
        self.index=0; self.sums=snap['sums_i64'];self.reads={};self.torn=False
        guard=snap['guard']
        self.regs={0:0x4d494301,0x40:0x444f4102,0x44:1,0x48:window,0x4c:window,
                   0x50:31250,0x54:0x04100604,0x70:window//4,0x74:0x00010304,
                   0x6c:guard['support']<<5|guard['match_mask']<<1|int(guard['stable'])}
        for base, p in [(0x64,snap['integer_peaks'])]+[(0x78+8*q,p) for q,p in enumerate(snap['subwindow_peaks'])]:
            bits=pack(p);self.regs[base]=bits&0xffffffff;self.regs[base+4]=bits>>32
    def write(self, addr, value):
        assert addr==0x58 and 0<=value<202
        self.index=value
    def read(self, addr):
        self.reads[addr]=self.reads.get(addr,0)+1
        if addr in (0x5c,0x60):return (self.sums[self.index]>>(32*(addr==0x60)))&0xffffffff
        if self.torn and addr==0x44 and self.reads[addr]>1:return 2
        return self.regs[addr]
rng=np.random.default_rng(281028)
x=rng.integers(-8388608,8388608,size=(291,4),dtype=np.int64)
snapshot=features(x,256)
got=read_snapshot(Registers(snapshot))
for key in ('sums_i64','integer_peaks','subwindow_peaks','guard'):
    ok('exact_'+key,got[key]==snapshot[key])
ok('contains_negative_i64',min(got['sums_i64'])<0)
ok('raw_index',got['first_center_raw_index']==31269 and got['last_input_raw_index']==31540)
for label,addr,val in [('capture_abi',0,0),('old_abi',0x40,0x444f4101),('channels',0x54,0),
                       ('guard_config',0x74,0),('not_ready',0x44,0),('overrun',0x44,5),
                       ('incomplete',0x4c,255),('window_large',0x48,65536),
                       ('quarter_size',0x70,63),('guard_bits',0x6c,255)]:
    reg=Registers(snapshot);reg.regs[addr]=val
    bad(label,lambda:read_snapshot(reg))
reg=Registers(snapshot);reg.torn=True
bad('torn_snapshot',lambda:read_snapshot(reg))
for q in range(4):
    reg=Registers(snapshot);reg.regs[0x78+8*q]=0x7f7f7f7f
    bad('out_of_range_sub_'+str(q),lambda:read_snapshot(reg))
for mask in range(16):
    snap=copy.deepcopy(snapshot)
    snap['subwindow_peaks']=[list(snapshot['integer_peaks']) for _ in range(4)]
    for q in range(4):
        if not mask&(1<<q):
            old=snap['integer_peaks'][0]
            snap['subwindow_peaks'][q][0]=old+2 if old<=14 else old-2
    snap['guard']=peak_guard(snap['integer_peaks'],snap['subwindow_peaks'])
    read=read_snapshot(Registers(snap))
    ok('mask_'+str(mask),read['guard']['match_mask']==mask and read['guard']['stable']==(mask.bit_count()>=3))
folder=ROOT/'build/mic_localize_V2/runtime_fixture_V1'
folder.mkdir()
for name in cli.RUNTIME:(folder/name).write_bytes(name.encode('ascii'))
manifest={'schema':1,'files':{name:hashlib.sha256((folder/name).read_bytes()).hexdigest() for name in cli.RUNTIME}}
(folder/cli.MANIFEST).write_text(json.dumps(manifest),encoding='utf-8')
ok('runtime_manifest',cli.check_bundle(folder)==manifest)
for name in cli.RUNTIME:
    original=(folder/name).read_bytes();(folder/name).write_bytes(original+b'tamper')
    bad('tamper_'+name,lambda:cli.check_bundle(folder))
    (folder/name).write_bytes(original)
for seconds in [0,2.99,10.01,float('nan'),float('inf')]:
    bad('invalid_seconds_'+str(seconds),lambda:cli.capture(folder,folder/'unused',seconds))
bad('existing_output',lambda:cli.capture(folder,folder,3))
ok('no_hardware_import','pynq' not in sys.modules)
out={'status':'PASS','checks':len(checks),'cases':checks,
     'scope':'Offline fake MMIO and runtime integrity; hardware NOT_RUN',
     'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SRC.glob('*.py'))}}
with (ROOT/'logs/mic_stability_V2/runtime_tests_V2.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2)
print(json.dumps({k:out[k] for k in ['status','checks','scope']}))
