Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:ProjectRoot = Split-Path -Parent $PSScriptRoot
$script:Vivado = 'D:\Vivado2026.1\2026.1\Vivado\bin\vivado.bat'
$script:Vitis = 'D:\Vivado2026.1\2026.1\Vitis\bin\vitis.bat'
$script:VivadoBin = Split-Path -Parent $script:Vivado

function Write-CommandRecord {
    param(
        [Parameter(Mandatory)][object]$Record,
        [string]$Path = (Join-Path $script:ProjectRoot 'logs\commands.log')
    )
    # Vivado, Vitis and XSim may finish concurrently. Serialize whole UTF-8 lines.
    $mutex = [System.Threading.Mutex]::new($false, 'Local\pynq_av_localizer_command_log')
    $acquired = $false
    try {
        try { $acquired = $mutex.WaitOne(30000) }
        catch [System.Threading.AbandonedMutexException] { $acquired = $true }
        if (-not $acquired) { throw 'Timed out acquiring the command log mutex.' }
        $json = $Record | ConvertTo-Json -Compress -Depth 8
        [System.IO.File]::AppendAllText($Path, $json + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))
    } finally {
        if ($acquired) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}

function Initialize-ProjectEnvironment {
    param([Parameter(Mandatory)][string]$WorkDirectory)
    if ($script:ProjectRoot -notmatch '^D:\\[A-Za-z0-9_.\\-]+$') {
        throw 'The project path must use ASCII letters, digits, underscores, hyphens or periods on D:.'
    }
    $temporary = Join-Path $script:ProjectRoot 'build\tmp'
    New-Item -ItemType Directory -Path $WorkDirectory, $temporary -Force | Out-Null
    $env:TEMP = $temporary
    $env:TMP = $temporary
    $env:PYTHONDONTWRITEBYTECODE = '1'
    $env:PYTHONUNBUFFERED = '1'
    $env:FPGA_PROJECT_ROOT = $script:ProjectRoot
}

function Invoke-LoggedTool {
    param(
        [Parameter(Mandatory)][string]$Task,
        [Parameter(Mandatory)][string]$Executable,
        [string[]]$Arguments = @(),
        [Parameter(Mandatory)][string]$WorkDirectory,
        [Parameter(Mandatory)][string]$LogPath,
        [string]$RequiredMarker = '',
        [int[]]$AcceptedExitCodes = @(0)
    )
    if (-not (Test-Path -LiteralPath $Executable)) { throw "Missing tool: $Executable" }
    if (Test-Path -LiteralPath $LogPath) { throw "Evidence log already exists; use a new RunName: $LogPath" }
    # Tee-Object may create no file when a successful native command is silent.
    New-Item -ItemType File -Path $LogPath -ErrorAction Stop | Out-Null
    $started = Get-Date
    $record = [ordered]@{
        time = $started.ToString('o'); task = $Task; executable = $Executable;
        arguments = @($Arguments); working_directory = $WorkDirectory;
        log = $LogPath; state = 'STARTED'; exit_code = $null
    }
    Write-CommandRecord -Record $record
    Push-Location -LiteralPath $WorkDirectory
    $oldPreference = $ErrorActionPreference
    try {
        # Native stderr is retained in the evidence log. Exit and marker are both checked below.
        $ErrorActionPreference = 'Continue'
        & $Executable @Arguments 2>&1 | Tee-Object -FilePath $LogPath
        $toolExit = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $oldPreference
        Pop-Location
    }
    $text = [string](Get-Content -LiteralPath $LogPath -Raw)
    $markerOK = $RequiredMarker -eq '' -or $text.Contains($RequiredMarker)
    $exitOK = $AcceptedExitCodes -contains $toolExit
    $record.state = if ($markerOK -and $exitOK) { 'PASS' } else { 'FAIL' }
    $record.exit_code = $toolExit
    $record['finished'] = (Get-Date).ToString('o')
    $record['required_marker'] = $RequiredMarker
    Write-CommandRecord -Record $record
    if (-not $markerOK -or -not $exitOK) {
        throw "$Task failed: exit=$toolExit marker=$markerOK; evidence=$LogPath"
    }
}
