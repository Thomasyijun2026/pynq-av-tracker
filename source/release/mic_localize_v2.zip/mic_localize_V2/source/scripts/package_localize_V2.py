"""Stage/seal an off-board-tested ABI2 candidate without replacing V1."""
import argparse, hashlib, json, shutil, sys, zipfile
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'release/mic_localize_V2'
LOG=ROOT/'logs/mic_stability_V2'
sys.path.insert(0,str(ROOT/'software/pynq/mic_doa_V2'))
from run_localizer_V2 import RUNTIME
from pl_reference import features,estimate
from direction import read_positions

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2,allow_nan=False,ensure_ascii=False)
def cp(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists():raise FileExistsError(dst)
    shutil.copyfile(src,dst)
    assert sha(src)==sha(dst)

def stage():
    build=read(ROOT/'logs/mic_localize_V2/build_verification.json')
    regression=read(LOG/'reference_regression_V2.json')
    assert build['status']=='OFFBOARD_PASS' and regression['summary']['status']=='PASS'
    assert read(LOG/'runtime_tests_V2.json')['status']=='PASS'
    assert read(LOG/'capture_verifier_tests_V2.json')['status']=='OFFLINE_VERIFIER_TEST_PASS'
    DEST.mkdir()
    software=ROOT/'software/pynq/mic_doa_V2'
    for name in RUNTIME:
        src=software/name
        if name.endswith(('.bit','.hwh')):src=ROOT/'build/mic_localize_V2/build_V1/output'/name
        if name.endswith('.csv'):src=ROOT/'hardware/mic_fanout_v1/exports'/name
        cp(src,DEST/name)
    for name in ['replay_bundle_V2.py','verify_capture.py','analyze_recording.py','delay.py']:
        cp(software/name,DEST/name)
    save(DEST/'runtime_manifest_localize_V2.json',{
        'schema':1,'board':'Pynq-Z2','board_root_uuid':'63b8b04d-af08-419a-a9dc-16f374e283dc',
        'files':{n:sha(DEST/n) for n in RUNTIME},
        'allowed_active_bit_sha256':[sha(DEST/'mic_localize.bit'),
            'cbb356191425ae8c9879a64d2a9516fe4992cdac18c8ce6931e3164865a69f1e',
            '0af194b60c95742b2aa7da39c6de0f904a6019b05ad0d7a476e47eafd748e0f0'],
        'release_status':'OFFBOARD_CANDIDATE','V2_board_validation':'NOT_RUN'})
    for subdir in ['fpga/audio_localize_V2','software/pynq/mic_doa_V2']:
        for p in sorted((ROOT/subdir).rglob('*')):
            if p.is_file() and p.suffix in ['.sv','.tcl','.xdc','.hex','.csv','.json','.md','.txt','.py','.ps1']:
                cp(p,DEST/'source'/p.relative_to(ROOT))
    for name in ['scripts/common.ps1','scripts/package_localize_V2.py',
                 'logs/mic_stability_V2/regress_reference_V2.py','logs/mic_stability_V2/make_rtl_vectors_V2.py',
                 'logs/mic_stability_V2/test_runtime_V2.py','logs/mic_stability_V2/test_capture_verifier_V2.py',
                 'logs/mic_stability_V2/make_test_audio_V1.py']:
        cp(ROOT/name,DEST/'source'/name)
    coords=read_positions(DEST/'component_coordinates_V20.csv',[1,5,7,8])
    rows=[]
    for rd,cap,wi,name,case_id in [(6,3,2,'jump006',5),(13,5,3,'jump013',6),(13,5,2,'stable013',7)]:
        run=ROOT/f'logs/mic_monitor_V1/round_{rd:03d}'
        verification=read(run/f'verification_{cap:02d}.json')
        source=run/'results'/verification['capture']/'raw_i32le.bin'
        assert sha(source)==verification['raw_sha256']
        raw=np.fromfile(source,dtype='<i4').reshape(-1,8)
        start=31250+wi*32768
        excerpt=np.ascontiguousarray(raw[start:start+32803,[0,4,6,7]])
        snap=features(excerpt)
        # Cross-check all scalar features and peaks against the actual XSim input oracle.
        vec=ROOT/f'fpga/audio_localize_V2/sim/vectors/case{case_id}_expected.hex'
        vals=[int(t,16) for t in vec.read_text().split()]
        vals=[v-(1<<64) if v&(1<<63) else v for v in vals]
        assert snap['sums_i64']==vals
        entry=DEST/'examples';entry.mkdir(exist_ok=True)
        path=entry/(name+'_i32le.bin')
        with path.open('xb') as f:f.write(excerpt.astype('<i4').tobytes())
        expected_name=name+'_reference.json'
        save(entry/expected_name,{'reference_snapshot':snap,'estimate':estimate(snap,coords),
             'provenance':'V1 physical recording; V2 reference validated by RTL simulation, not V2 board',
             'source_relative_path':source.relative_to(ROOT).as_posix(),
             'source_sha256':verification['raw_sha256'],'start_raw_frame':start,
             'frames':32803,'channels':[1,5,7,8],'rtl_case_id':case_id})
        rows.append({'name':name,'raw_file':path.name,'raw_sha256':sha(path),'expected_file':expected_name})
    save(DEST/'examples/manifest.json',{'scope':'V1 recordings for V2 offline/RTL replay','cases':rows})
    reduced={k:v for k,v in regression.items() if k!='recordings'}
    reduced['full_local_evidence']={'path':'logs/mic_stability_V2/reference_regression_V2.json',
                                    'sha256':sha(LOG/'reference_regression_V2.json')}
    save(DEST/'evidence/reference_regression_summary_V2.json',reduced)
    for path in ['logs/mic_localize_V2/build_verification.json','logs/mic_localize_V2/review.md','logs/mic_localize_V2/sim_unit_V2.console.log',
                 'logs/mic_localize_V2/sim_interface_V1.console.log','logs/mic_stability_V2/runtime_tests_V2.json',
                 'logs/mic_stability_V2/capture_verifier_tests_V2.json','logs/mic_stability_V2/build_source_manifest.json',
                 'logs/mic_stability_V2/rtl_vectors_V2.json']:
        cp(ROOT/path,DEST/'evidence'/Path(path).name)
    for name in ['timing_summary.rpt','timing_metrics.tsv','utilization.rpt','drc.rpt','methodology.rpt','cdc.rpt','check_timing.rpt']:
        cp(ROOT/'build/mic_localize_V2/build_V1/reports'/name,DEST/'evidence/reports'/name)
    cp(ROOT/'docs/mic_sound_test_V2.md',DEST/'SOUND_TEST.md')
    cp(ROOT/'docs/mic_stability_V2.md',DEST/'DESIGN_AND_ACCEPTANCE.md')
    cp(ROOT/'release/mic_test_source_V1/broadband_20s_V1.wav',DEST/'sound/broadband_20s_V1.wav')
    cp(ROOT/'release/mic_test_source_V1/manifest.json',DEST/'sound/manifest.json')
    print('STAGED_OFFBOARD_CANDIDATE',str(DEST))

def seal():
    assert read(LOG/'package_replay_V2.json')['status']=='OFFLINE_REPLAY_PASS'
    assert read(LOG/'package_integrity_tests_V2.json')['status']=='PASS'
    cp(LOG/'package_replay_V2.json',DEST/'evidence/package_replay_V2.json')
    cp(LOG/'package_integrity_tests_V2.json',DEST/'evidence/package_integrity_tests_V2.json')
    cp(ROOT/'report/mic_stability_V2.md',DEST/'TEST_REPORT.md')
    assert (DEST/'README.md').is_file()
    files={p.relative_to(DEST).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(DEST.rglob('*')) if p.is_file()}
    save(DEST/'manifest.json',{'schema':1,'files':files,'release_status':'OFFBOARD_CANDIDATE',
                            'V2_board_validation':'NOT_RUN','physical_accuracy':'NOT_VALIDATED'})
    target=DEST.with_suffix('.zip')
    with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(DEST.rglob('*')):
            if p.is_file():z.write(p,DEST.name+'/'+p.relative_to(DEST).as_posix())
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)+1
        assert len(set(z.namelist()))==len(z.namelist())
        for name,item in files.items():
            data=z.read(DEST.name+'/'+name)
            assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
    result={'status':'ZIP_CRC_SHA_PASS','bytes':target.stat().st_size,'members':len(files)+1,'zip_sha256':sha(target),
            'release_status':'OFFBOARD_CANDIDATE','V2_board_validation':'NOT_RUN','physical_accuracy':'NOT_VALIDATED'}
    save(ROOT/'release/mic_localize_package_V2.json',result)
    print(json.dumps(result))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['stage','seal'])
    {'stage':stage,'seal':seal}[p.parse_args().action]()
